package com.dgs.translateofdgs

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions


private data class Item(val rect: Rect, val text: String)

private class ResultView(ctx: Context, private val items: List<Item>) : View(ctx) {
    private val bgPaint = Paint().apply { color = 0xEE101820.toInt(); style = Paint.Style.FILL }
    private val strokePaint = Paint().apply {
        color = 0xFF16E0D3.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true
    }
    private val tp = TextPaint().apply { color = Color.WHITE; isAntiAlias = true }

    private fun fit(text: String, w: Int, h: Int): StaticLayout {
        var size = h.toFloat().coerceAtMost(60f).coerceAtLeast(18f)
        while (true) {
            tp.textSize = size
            val l = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).build()
            if (l.height <= h + 4 || size <= 18f) return l
            size -= 2f
        }
    }

    override fun onDraw(c: Canvas) {
        for (item in items) {
            val r = item.rect
            val rr = RectF(r.left - 4f, r.top - 2f, r.right + 4f, r.bottom + 2f)
            c.drawRoundRect(rr, 8f, 8f, bgPaint)
            c.drawRoundRect(rr, 8f, 8f, strokePaint)
            val layout = fit(item.text, r.width().coerceAtLeast(80), r.height())
            c.save()
            c.translate(r.left.toFloat(), r.top.toFloat())
            layout.draw(c)
            c.restore()
        }
    }
}

class ScreenTranslateService : Service() {
    companion object {
        const val ACTION_STOP = "com.dgs.translateofdgs.STOP"
        private const val CH = "dgs_screen"
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var wm: WindowManager? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var autoLabel: TextView? = null
    private var resultView: ResultView? = null
    private var recognizer: TextRecognizer? = null
    private var fromCode = "en"
    private var toCode = "tr"
    private var lastBitmap: Bitmap? = null
    private var lastConv = 0L
    private var quietUntil = 0L
    private var busy = false
    private var auto = false
    private var closing = false

    @Volatile private var pending = false
    @Volatile private var overlayShown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        fromCode = intent.getStringExtra("from") ?: "en"
        toCode = intent.getStringExtra("to") ?: "tr"
        startAsForeground()
        if (projection != null) return START_NOT_STICKY
        try {
            setupCapture(code, data)
            showPanel()
        } catch (e: Exception) {
            toast("Ekran çevirisi başlatılamadı: ${e.localizedMessage ?: "hata"}")
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Ekran çevirisi", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CH)
            .setContentTitle("Translate of DGS")
            .setContentText("Ekran çevirisi açık")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Kapat", stop)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        (wm ?: getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm
    }

    private fun setupCapture(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        thread = HandlerThread("dgs-capture").also { it.start() }
        bg = Handler(thread!!.looper)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)
        val dm = metrics()
        val r = attachReader(dm.widthPixels, dm.heightPixels)
        reader = r
        vDisplay = proj.createVirtualDisplay(
            "dgs-capture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg,
        )
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun attachReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, bg)
        return r
    }

    private fun onFrame(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            val wanted = pending && now >= quietUntil
            val periodic = !pending && !overlayShown && now >= quietUntil && now - lastConv > 800
            if (wanted || periodic) {
                val bmp = toBitmap(img)
                lastBitmap = bmp
                lastConv = now
                if (wanted) { pending = false; main.post { process(bmp) } }
            }
        } catch (e: Exception) {
        } finally {
            img.close()
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(plane.buffer)
        return if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }


    private fun requestCapture() {
        if (busy) return
        busy = true
        if (overlayShown) {
            removeResult()
            lastBitmap = null
            quietUntil = SystemClock.uptimeMillis() + 250
        } else {
            quietUntil = 0L
        }
        pending = true
        main.postDelayed({
            if (pending) {
                pending = false
                val b = lastBitmap
                if (b != null) process(b) else { busy = false; toast("Ekran görüntüsü alınamadı, tekrar dene.") }
            }
        }, 900)
    }

    private fun process(bmp: Bitmap) {
        val rec = recognizer
        if (rec == null) { busy = false; return }
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val pr = panelRect()
                val blocks = res.textBlocks.filter { b ->
                    val r = b.boundingBox
                    r != null && b.text.isNotBlank() && !(pr != null && Rect.intersects(r, pr))
                }.take(25)
                if (blocks.isEmpty()) {
                    busy = false
                    toast("Ekranda çevrilecek yazı bulunamadı.")
                } else translateBlocks(blocks.map { Item(Rect(it.boundingBox!!), it.text.replace("\n", " ")) })
            }
            .addOnFailureListener { busy = false; toast("Yazı okunamadı.") }
    }

    private fun translateBlocks(blocks: List<Item>) {
        val out = java.util.Collections.synchronizedList(ArrayList<Item>())
        val left = java.util.concurrent.atomic.AtomicInteger(blocks.size)
        fun done() {
            if (left.decrementAndGet() == 0) {
                busy = false
                if (out.isEmpty()) toast("Çeviri yapılamadı. İnternet bağlantını kontrol et.")
                else showResult(ArrayList(out))
            }
        }
        if (fromCode == toCode) {
            busy = false
            showResult(blocks)
            return
        }
        for (b in blocks) {
            translateText(b.text, fromCode, toCode) { res, ok ->
                if (ok) out.add(Item(b.rect, res))
                done()
            }
        }
    }

    private fun showResult(items: List<Item>) {
        removeResult()
        val w = wm ?: return
        val v = ResultView(this, items)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            w.addView(v, lp)
            resultView = v
            overlayShown = true
            val pv = panel
            val pl = panelParams
            if (pv != null && pl != null) { w.removeView(pv); w.addView(pv, pl) }
        } catch (e: Exception) {
            toast("Çeviri ekrana çizilemedi.")
        }
    }

    private fun removeResult() {
        resultView?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        resultView = null
        overlayShown = false
    }

    private fun panelRect(): Rect? {
        val v = panel
        val lp = panelParams
        if (v == null || lp == null) return null
        return Rect(lp.x - 12, lp.y - 12, lp.x + v.width + 12, lp.y + v.height + 12)
    }

    private fun showPanel() {
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun pad(v: Int) = (v * d).toInt()
        fun label(t: String, click: (() -> Unit)?): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            tv.setPadding(pad(11), pad(8), pad(11), pad(8))
            if (click != null) tv.setOnClickListener { click() }
            return tv
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.background = GradientDrawable().apply {
            setColor(0xEE071317.toInt()); cornerRadius = 26 * d; setStroke(pad(1), 0xFF16E0D3.toInt())
        }
        row.setPadding(pad(4), pad(2), pad(4), pad(2))

        val handle = label("⠿", null)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = pad(16); y = pad(140) }
        panelParams = lp
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        panel?.let { try { w.updateViewLayout(it, lp) } catch (_: Exception) { } }
                    }
                }
                return true
            }
        })
        val translate = label("Çevir") { requestCapture() }
        translate.setTextColor(0xFF16E0D3.toInt())
        val autoBtn = label("Oto: kapalı") {
            auto = !auto
            autoLabel?.text = if (auto) "Oto: açık" else "Oto: kapalı"
            main.removeCallbacks(autoRun)
            if (auto) main.post(autoRun)
        }
        autoLabel = autoBtn
        val clear = label("Temizle") { removeResult() }
        val close = label("✕") { shutdown() }
        row.addView(handle); row.addView(translate); row.addView(autoBtn); row.addView(clear); row.addView(close)
        panel = row
        w.addView(row, lp)
    }

    private val autoRun = object : Runnable {
        override fun run() {
            if (auto && !closing) {
                requestCapture()
                main.postDelayed(this, 3000)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection == null) return
        try {
            val dm = metrics()
            removeResult()
            lastBitmap = null
            val old = reader
            val r = attachReader(dm.widthPixels, dm.heightPixels)
            reader = r
            vDisplay?.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi)
            vDisplay?.surface = r.surface
            old?.close()
        } catch (e: Exception) {
            toast("Ekran döndürüldü, çeviriyi yeniden başlat.")
        }
    }

    private fun toast(t: String) {
        main.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }
    }

    private fun cleanup() {
        auto = false
        pending = false
        main.removeCallbacksAndMessages(null)
        removeResult()
        panel?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        panel = null
        try { vDisplay?.release() } catch (_: Exception) { }
        vDisplay = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) { }
        recognizer?.close(); recognizer = null
        thread?.quitSafely(); thread = null
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        cleanup()
        stopForeground(Service.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        closing = true
        cleanup()
        super.onDestroy()
    }
}
