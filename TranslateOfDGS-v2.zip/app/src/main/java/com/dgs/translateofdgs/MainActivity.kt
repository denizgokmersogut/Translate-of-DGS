package com.dgs.translateofdgs

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TranslateDgsApp() }
    }
}

private enum class Screen { HOME, TEXT, PHOTO, CAMERA, SCREEN, HISTORY, SETTINGS }
private data class Language(val label: String, val code: String)
private data class Entry(val src: String, val tr: String, val photo: Boolean, val time: Long)
private class Pal(
    val bg: Color, val card: Color, val border: Color, val ink: Color,
    val muted: Color, val tq: Color, val dark: Boolean,
)

private val darkPal = Pal(Color(0xFF050B0E), Color(0xFF0E1A1F), Color(0xFF1F3A40), Color.White, Color(0xFF9CB4BA), Color(0xFF16E0D3), true)
private val lightPal = Pal(Color(0xFFF4FAFA), Color.White, Color(0xFFCDE9E7), Color(0xFF12343A), Color(0xFF607A80), Color(0xFF0FB5AB), false)
private val onTq = Color(0xFF031316)

private val langs = listOf(
    Language("Türkçe", "tr"), Language("English", "en"),
    Language("Deutsch", "de"), Language("Français", "fr"),
    Language("Español", "es"), Language("Русский", "ru"),
    Language("日本語", "ja"), Language("한국어", "ko"),
    Language("中文", "zh-CN"), Language("Italiano", "it"),
)

private fun loadHistory(ctx: Context): List<Entry> {
    val raw = ctx.getSharedPreferences("dgs_prefs", 0).getString("history", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getString("s"), o.getString("t"), o.optBoolean("p"), o.optLong("d"))
        }
    } catch (e: Exception) { emptyList() }
}

private fun saveHistory(ctx: Context, list: List<Entry>) {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("s", it.src).put("t", it.tr).put("p", it.photo).put("d", it.time)) }
    ctx.getSharedPreferences("dgs_prefs", 0).edit().putString("history", arr.toString()).apply()
}

private fun copyToClipboard(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Çeviri", text))
    Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
}

@Composable
private fun TranslateDgsApp() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var textInput by remember { mutableStateOf("") }
    var translated by remember { mutableStateOf("") }
    var recognized by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf(langs.first()) }
    var source by remember { mutableStateOf(langs[1]) }
    var errorText by remember { mutableStateOf("") }
    var darkMode by remember { mutableStateOf(context.getSharedPreferences("dgs_prefs", 0).getBoolean("dark_mode", true)) }
    val history = remember { mutableStateListOf<Entry>().apply { addAll(loadHistory(context)) } }

    fun addEntry(src: String, tr: String, photo: Boolean) {
        history.add(0, Entry(src, tr, photo, System.currentTimeMillis()))
        while (history.size > 50) history.removeAt(history.size - 1)
        saveHistory(context, history.toList())
    }
    fun openScreen(s: Screen) { screen = s; errorText = ""; translated = ""; recognized = "" }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            openScreen(Screen.PHOTO)
            isBusy = true
            try {
                val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) {
                    errorText = "Fotoğraf okunamadı."; isBusy = false
                } else runOcr(bitmap) { text ->
                    recognized = text
                    if (text.isBlank()) {
                        errorText = "Fotoğrafta yazı bulunamadı."; isBusy = false
                    } else translateText(text, source.code, target.code) { result, ok ->
                        translated = result; isBusy = false
                        if (ok) addEntry(text, result, true)
                    }
                }
            } catch (e: Exception) {
                errorText = e.localizedMessage ?: "Fotoğraf açılamadı"; isBusy = false
            }
        }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScreen(Screen.CAMERA) else errorText = "Kamera izni olmadan canlı çeviri açılamaz."
    }
    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val svc = Intent(context, ScreenTranslateService::class.java)
                .putExtra("code", res.resultCode).putExtra("data", data)
                .putExtra("from", source.code).putExtra("to", target.code)
            ContextCompat.startForegroundService(context, svc)
            Toast.makeText(context, "Ekran çevirisi açıldı. Çevirmek istediğin uygulamaya geç.", Toast.LENGTH_LONG).show()
            (context as? Activity)?.moveTaskToBack(true)
        } else errorText = "Ekran yakalama izni verilmedi."
    }
    fun startScreenTranslation() {
        errorText = ""
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "Önce 'Diğer uygulamaların üzerinde göster' iznini aç, sonra geri dönüp tekrar başlat.", Toast.LENGTH_LONG).show()
            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        } else {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    val p = if (darkMode) darkPal else lightPal
    val scheme = if (darkMode) darkColorScheme(primary = p.tq, background = p.bg, surface = p.card)
    else lightColorScheme(primary = p.tq, background = p.bg, surface = p.card)

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = p.bg,
            bottomBar = {
                val tab = when (screen) { Screen.HISTORY -> 1; Screen.SETTINGS -> 2; else -> 0 }
                NavigationBar(containerColor = p.bg) {
                    NavItem(p, tab == 0, Icons.Outlined.Home, "Ana sayfa") { openScreen(Screen.HOME) }
                    NavItem(p, tab == 1, Icons.Outlined.History, "Geçmiş") { openScreen(Screen.HISTORY) }
                    NavItem(p, tab == 2, Icons.Outlined.Settings, "Ayarlar") { openScreen(Screen.SETTINGS) }
                }
            },
        ) { inner ->
            Column(
                Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        p, history,
                        onText = { openScreen(Screen.TEXT) },
                        onPhoto = { gallery.launch("image/*") },
                        onCamera = { cameraPermission.launch(Manifest.permission.CAMERA) },
                        onScreen = { openScreen(Screen.SCREEN) },
                        onStartScreen = { startScreenTranslation() },
                        onSettings = { openScreen(Screen.SETTINGS) },
                        onHistory = { openScreen(Screen.HISTORY) },
                        onCopy = { copyToClipboard(context, it) },
                    )
                    Screen.TEXT -> {
                        ScreenTitle(p, "Metin çevirisi") { screen = Screen.HOME }
                        LangRow(p, source, target, { source = it }, { target = it })
                        OutlinedTextField(
                            textInput, { textInput = it; translated = "" },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Çevrilecek metin") }, minLines = 4,
                        )
                        PrimaryButton(p, "ÇEVİR", isBusy) {
                            isBusy = true; errorText = ""
                            translateText(textInput, source.code, target.code) { result, ok ->
                                translated = result; isBusy = false
                                if (ok) addEntry(textInput, result, false)
                            }
                        }
                        if (translated.isNotBlank()) ResultCard(p, "Çeviri", translated) { copyToClipboard(context, translated) }
                    }
                    Screen.PHOTO -> {
                        ScreenTitle(p, "Fotoğraf çevirisi") { screen = Screen.HOME }
                        LangRow(p, source, target, { source = it }, { target = it })
                        PrimaryButton(p, "Galeriden fotoğraf seç", isBusy) { gallery.launch("image/*") }
                        if (recognized.isNotBlank()) ResultCard(p, "Algılanan metin", recognized, null)
                        if (translated.isNotBlank()) ResultCard(p, "Çeviri", translated) { copyToClipboard(context, translated) }
                    }
                    Screen.CAMERA -> {
                        ScreenTitle(p, "Kamera canlı çeviri") { screen = Screen.HOME }
                        LangRow(p, source, target, { source = it }, { target = it })
                        CameraTranslator(p, source.code, target.code, { recognized = it }, { translated = it }, { isBusy = it })
                        if (recognized.isNotBlank()) ResultCard(p, "Algılanan metin", recognized, null)
                        if (translated.isNotBlank()) ResultCard(p, "Çeviri", translated) { copyToClipboard(context, translated) }
                    }
                    Screen.SCREEN -> {
                        ScreenTitle(p, "Ekran çevirisi") { screen = Screen.HOME }
                        LangRow(p, source, target, { source = it }, { target = it })
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text("Nasıl çalışır", color = p.ink, fontWeight = FontWeight.Bold)
                            Text(
                                "1. Başlat'a bas ve istenen izinleri ver.\n2. Çevirmek istediğin uygulamaya veya oyuna geç.\n3. Yüzen paneldeki Çevir'e bas, ekrandaki yazılar çevrilip üstüne yazılır.\n4. Oto'yu açarsan yaklaşık 3 saniyede bir kendiliğinden yenilenir.",
                                color = p.muted,
                            )
                            Text(
                                "Not: Netflix gibi korumalı videolarda ekran siyah yakalanır, çalışmaz. Yazı okuma şimdilik Latin harfli diller içindir (İngilizce, Almanca, Fransızca...).",
                                color = p.muted, fontSize = 12.sp,
                            )
                        }
                        PrimaryButton(p, "Ekran çevirisini başlat", false) { startScreenTranslation() }
                        OutlinedButton(
                            onClick = { context.stopService(Intent(context, ScreenTranslateService::class.java)) },
                            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp),
                            border = BorderStroke(1.dp, p.tq),
                        ) { Text("Durdur", color = p.tq) }
                    }
                    Screen.HISTORY -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.History, null, tint = p.tq)
                            Spacer(Modifier.width(8.dp))
                            Text("Geçmiş", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (history.isNotEmpty()) TextButton(onClick = { history.clear(); saveHistory(context, emptyList()) }) {
                                Text("Temizle", color = p.tq)
                            }
                        }
                        if (history.isEmpty()) Text("Henüz çeviri yok.", color = p.muted)
                        history.forEach { HistoryRow(p, it) { t -> copyToClipboard(context, t) } }
                    }
                    Screen.SETTINGS -> {
                        Text("Ayarlar", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                        ) {
                            Text("Görünüm", color = p.ink, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (darkMode) "Karanlık mod" else "Aydınlık mod", color = p.muted, modifier = Modifier.weight(1f))
                                Switch(checked = darkMode, onCheckedChange = {
                                    darkMode = it
                                    context.getSharedPreferences("dgs_prefs", 0).edit().putBoolean("dark_mode", it).apply()
                                })
                            }
                        }
                        ContactCard(p)
                    }
                }
                if (isBusy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.tq)
                if (errorText.isNotBlank()) Text(errorText, color = Color(0xFFFF8B8B))
                Text(
                    "Çeviri cihaz üzerinde ML Kit ile yapılır. İlk kullanımda dil modeli indirilebilir.",
                    color = p.muted, fontSize = 11.sp,
                )
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(p: Pal, selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = p.tq, selectedTextColor = p.tq,
            unselectedIconColor = p.muted, unselectedTextColor = p.muted,
            indicatorColor = Color.Transparent,
        ),
    )
}

@Composable
private fun HomeScreen(
    p: Pal, history: List<Entry>,
    onText: () -> Unit, onPhoto: () -> Unit, onCamera: () -> Unit, onScreen: () -> Unit, onStartScreen: () -> Unit,
    onSettings: () -> Unit, onHistory: () -> Unit, onCopy: (String) -> Unit,
) {
    Box(Modifier.fillMaxWidth().height(120.dp)) {
    WaveBackground(p, Modifier.matchParentSize())
    Row(Modifier.fillMaxWidth().align(Alignment.TopCenter), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.dgs_logo), contentDescription = null, modifier = Modifier.size(84.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Translate", color = p.ink, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            Text("of DGS", color = p.tq, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            Text("Akıllı çeviri merkezi", color = p.muted, fontSize = 13.sp)
            Box(Modifier.padding(top = 4.dp).width(60.dp).height(2.dp).background(p.tq))
        }
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, p.tq, RoundedCornerShape(12.dp)).clickable { onSettings() },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.Settings, contentDescription = "Ayarlar", tint = p.tq) }
    }
    }

    Box(
        Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(p.card, if (p.dark) Color(0xFF0A2A30) else Color(0xFFE2F7F5))))
            .border(1.dp, p.border, RoundedCornerShape(20.dp)).clickable { onText() },
    ) {
        Image(
            painterResource(R.drawable.dgs_globe), contentDescription = null,
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(190.dp),
            contentScale = ContentScale.Crop,
        )
        Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(64.dp).clip(RoundedCornerShape(2.dp)).background(p.tq))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Anında çevir", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Dilediğin metni hızlıca\nkendi diline çevir", color = p.muted, fontSize = 14.sp)
            }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.Description, "Metin çevirisi", Modifier.weight(1f), onText)
        TileCard(p, Icons.Outlined.PhotoCamera, "Kamera", Modifier.weight(1f), onCamera)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.ImageIcon, "Fotoğraf", Modifier.weight(1f), onPhoto)
        TileCard(p, Icons.Outlined.CropFree, "Ekran çevirisi", Modifier.weight(1f), onScreen)
    }

    Row(
        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(29.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF22E8E0), Color(0xFF12C9CC)))).clickable { onStartScreen() },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Outlined.CropFree, null, tint = onTq)
        Spacer(Modifier.width(10.dp))
        Text("Ekran çevirisini başlat", color = onTq, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Filled.PlayArrow, null, tint = onTq)
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.History, null, tint = p.tq)
        Spacer(Modifier.width(8.dp))
        Text("Son çeviriler", color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Row(Modifier.clickable { onHistory() }, verticalAlignment = Alignment.CenterVertically) {
            Text("Tümünü gör", color = p.tq, fontSize = 14.sp)
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.tq)
        }
    }
    if (history.isEmpty()) Text("Henüz çeviri yok. İlk çevirini yaptığında burada görünecek.", color = p.muted, fontSize = 13.sp)
    history.take(2).forEach { HistoryRow(p, it, onCopy) }

    ContactCard(p)
}

@Composable
private fun TileCard(p: Pal, icon: ImageVector, title: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp)).clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = p.tq, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.ink, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }
    }
}

@Composable
private fun HistoryRow(p: Pal, e: Entry, onCopy: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (e.photo) Icons.Outlined.ImageIcon else Icons.Outlined.Description, null, tint = p.ink, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.src, color = p.ink, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text("→ ${e.tr}", color = p.tq, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
        IconButton(onClick = { onCopy(e.tr) }) { Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted) }
    }
}

@Composable
private fun ContactCard(p: Pal) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).border(1.dp, p.tq, RoundedCornerShape(16.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Person, null, tint = p.muted, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(1.dp).height(40.dp).background(p.border))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("Tasarım & Geliştirme", color = p.muted, fontSize = 11.sp)
            Text("Deniz Gökmer Söğüt", color = p.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(1.dp).height(40.dp).background(p.border))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Bize Ulaşın", color = p.muted, fontSize = 11.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(Color(0xFFE1306C), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("Denizgokmersogut", color = p.ink, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(Color(0xFF29A9EB), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("Denizgokmersogut", color = p.ink, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ScreenTitle(p: Pal, title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Geri", color = p.tq) }
        Text(title, color = p.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun PrimaryButton(p: Pal, title: String, loading: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = !loading, modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(25.dp),
        colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq),
    ) { Text(if (loading) "İŞLENİYOR…" else title, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ResultCard(p: Pal, title: String, content: String, onCopy: (() -> Unit)?) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(16.dp)).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.tq, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (onCopy != null) IconButton(onClick = onCopy) { Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted) }
        }
        Text(content, color = p.ink)
    }
}

@Composable
private fun LangRow(p: Pal, source: Language, target: Language, onSource: (Language) -> Unit, onTarget: (Language) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        LangPicker(p, "Kaynak", source, onSource, Modifier.weight(1f))
        LangPicker(p, "Hedef", target, onTarget, Modifier.weight(1f))
    }
}

@Composable
private fun LangPicker(p: Pal, label: String, selected: Language, onSelect: (Language) -> Unit, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, p.tq),
        ) { Text("$label: ${selected.label}", color = p.ink, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            langs.forEach { l -> DropdownMenuItem(text = { Text(l.label) }, onClick = { onSelect(l); expanded = false }) }
        }
    }
}

private fun runOcr(bitmap: Bitmap, callback: (String) -> Unit) {
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    recognizer.process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { result -> callback(result.text) }
        .addOnFailureListener { callback("") }
        .addOnCompleteListener { recognizer.close() }
}

internal fun translateText(text: String, from: String, to: String, callback: (String, Boolean) -> Unit) {
    val mainHandler = Handler(Looper.getMainLooper())
    if (text.isBlank()) { mainHandler.post { callback("Bir metin gir.", false) }; return }
    if (from == to) { mainHandler.post { callback(text, true) }; return }
    Thread {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$from&tl=$to&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val outer = JSONArray(response)
            val segments = outer.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i)
                if (seg != null && !seg.isNull(0)) {
                    sb.append(seg.getString(0))
                }
            }
            val result = sb.toString().trim()
            if (result.isNotEmpty()) {
                mainHandler.post { callback(result, true) }
            } else {
                mainHandler.post { callback("Çeviri sonucu boş döndü.", false) }
            }
        } catch (e: Exception) {
            mainHandler.post { callback("Çeviri hatası: İnternet bağlantını kontrol et.", false) }
        }
    }.start()
}

@OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
private fun CameraTranslator(
    p: Pal, sourceCode: String, targetCode: String,
    onRecognized: (String) -> Unit, onTranslated: (String) -> Unit, onBusy: (Boolean) -> Unit,
) {
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val ctxForDispose = LocalContext.current
    DisposableEffect(Unit) {
        onDispose {
            try { ProcessCameraProvider.getInstance(ctxForDispose).get().unbindAll() } catch (_: Exception) { }
        }
    }
    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analyzer = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                var lastRun = 0L
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                analyzer.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                    val now = System.currentTimeMillis()
                    if (now - lastRun > 2200) {
                        lastRun = now
                        val media = imageProxy.image
                        if (media != null) {
                            val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
                            recognizer.process(input).addOnSuccessListener { result ->
                                val text = result.text.trim()
                                if (text.isNotBlank()) {
                                    onRecognized(text); onBusy(true)
                                    translateText(text, sourceCode, targetCode) { translated, _ -> onTranslated(translated); onBusy(false) }
                                }
                            }.addOnCompleteListener { imageProxy.close() }
                        } else imageProxy.close()
                    } else imageProxy.close()
                }
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analyzer)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(16.dp)),
    )
    Text("Kamerayı yazıya veya televizyon altyazısına doğrult. OCR yaklaşık 2 saniyede bir yenilenir.", color = p.muted, fontSize = 13.sp)
}

@Composable
private fun WaveBackground(p: Pal, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val glow = if (p.dark) 1f else 0.6f
        fun band(y0: Float, c1: Float, c2: Float, y1: Float, thick: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
                cubicTo(w * 0.65f, c2 + thick, w * 0.35f, c1 + thick, 0f, y0 + thick * 0.3f)
                close()
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w))
        }
        fun line(y0: Float, c1: Float, c2: Float, y1: Float, width: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w), style = Stroke(width = width))
        }
        band(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, h * 0.22f, 0.28f)
        band(h * 1.15f, h * 1.15f, h * 0.45f, h * 0.35f, h * 0.12f, 0.18f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 14f, 0.10f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 6f, 0.30f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 2.5f, 0.90f)
        line(h * 1.12f, h * 1.15f, h * 0.4f, h * 0.3f, 2f, 0.55f)
    }
}
