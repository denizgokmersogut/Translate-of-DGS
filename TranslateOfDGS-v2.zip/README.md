# Translate of DGS

Android translation app starter project (Kotlin + Jetpack Compose + Google ML Kit).

## Current prototype features
- New home design (logo, globe hero card, 2x2 tiles, recent translations, contact card, bottom navigation)
- Translation history (last 50, saved locally, copy button)
- Text translation using on-device ML Kit Translate (language models downloaded as needed)
- Photo OCR with gallery picker
- Camera live OCR/translation preview
- Theme setting: dark (black + turquoise) / light (white + turquoise), preference persisted locally
- Settings/contact section: Designer & developer Deniz Gökmer Söğüt; Instagram and Telegram handle Denizgokmersogut

- Screen translation: MediaProjection + overlay panel (Çevir / Oto / Temizle / Kapat), Latin-script OCR

## Not implemented yet
- Video subtitle replacement/overlay integration
- Non-Latin OCR (Japanese, Korean, Chinese, Russian) for screen/photo/camera

Open in Android Studio or a compatible Android IDE and build the project to produce an APK.

## APK oluşturma
**Android Studio:** klasörü aç → Build > Build APK(s). Çıktı: `app/build/outputs/apk/debug/app-debug.apk`
**GitHub:** projeyi bir repoya yükle → Actions > "Build APK" çalışır → Artifacts içinden `TranslateOfDGS-apk` indir.
